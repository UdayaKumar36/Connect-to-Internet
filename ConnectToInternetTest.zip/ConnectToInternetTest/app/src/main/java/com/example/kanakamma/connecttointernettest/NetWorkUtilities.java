package com.example.kanakamma.connecttointernettest;

import android.net.Uri;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Kanakamma on 8/31/2017.
 */

public class NetWorkUtilities {

    private static final String Url="https://www.googleapis.com/books/v1/volumes?";
    private static final String Query_Param="q";
    private static final String Max_Result="max";
    private static final String Print_Type="printtype";


    static String getBookInfo(String queyString)
    {
        HttpURLConnection urlConnection=null;
        BufferedReader bufferedReader=null;
        String bookJSON=null;

        Uri buildUri=Uri.parse(Url).buildUpon()
                .appendQueryParameter(Query_Param,queyString)
                .appendQueryParameter(Max_Result,"10")
                .appendQueryParameter(Print_Type,"books")
                .build();


        URL requesturl= null;
        try {
            requesturl = new URL(buildUri.toString());
            urlConnection=(HttpURLConnection)requesturl.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            InputStream inputStream=urlConnection.getInputStream();
            StringBuffer stringBuffer=new StringBuffer();

            if(inputStream==null)
            {
                return null;
            }

            bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line=bufferedReader.readLine())!=null)
            {
            stringBuffer.append(line +"\n");
            }
            if(stringBuffer.length()==0)
            {
                return null;
            }
            bookJSON=stringBuffer.toString();



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return bookJSON;
    }

}
