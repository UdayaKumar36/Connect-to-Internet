package com.example.kanakamma.connecttointernettest;

import android.os.AsyncTask;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Kanakamma on 8/31/2017.
 */

public class Fetch extends AsyncTask<String,Void,String> {


    TextView mAuthor,mTitle;


    public Fetch(TextView tv1, TextView tv2) {
        mAuthor=tv1;
        mTitle=tv2;


    }

    @Override
    protected String doInBackground(String... params) {
        return NetWorkUtilities.getBookInfo(params[0]);
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        try {
            JSONObject jsonobject=new JSONObject(s);
            JSONArray array=jsonobject.getJSONArray("items");
            for(int i=0;i<array.length();i++)
            {
                JSONObject book=array.getJSONObject(i);
                String title=null;
                String author=null;
                JSONObject volumeinfo=book.getJSONObject("volumeInfo");
                title=volumeinfo.getString("title");
                author=volumeinfo.getString("authors");
                if(title !=null && author !=null)
                {
                    mAuthor.setText(author);
                    mTitle.setText(title);
                }



            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
