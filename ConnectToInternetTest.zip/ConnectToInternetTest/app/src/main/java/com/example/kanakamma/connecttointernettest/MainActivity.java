package com.example.kanakamma.connecttointernettest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv1,tv2;
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1=(TextView)findViewById(R.id.textView2);
        tv2=(TextView)findViewById(R.id.textView3);
        editText=(EditText)findViewById(R.id.editText);
    }

    public void connecttonet(View view) {
        String data=editText.getText().toString();
        new Fetch(tv1,tv2).execute(data);
    }
}
